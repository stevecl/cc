let e={title:"辅助线",height:1,lineColor:"#000",type:"solid",style:{background:"#ededed",padding:"5px 5px 5px 5px",margin:"0 0 0 0"}};export{e as default};
