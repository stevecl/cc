let o={title:"浮动按钮",showType:1,showPosi:1,marginTop:10,marginLeft:10,iconSpace:10,iconColor:"#fff",bgColor:"#FD463E",datas:[{icon:"icon-shouye",img:"",link:""}]};export{o as default};
