let e={title:"辅助空白",style:{height:"20px",margin:"0 0 0 0",backgroundColor:"#ededed"}};export{e as default};
